"""
GUI package initialization.
"""
