"""Security package initialization."""
