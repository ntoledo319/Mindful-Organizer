"""
Mindful Optimizer package initialization.
"""
